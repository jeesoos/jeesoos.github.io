var vblog={
        login:'vik',
		replieLink:'blogs',
		followTag:'ru--otkrytyij-kod',

};	
