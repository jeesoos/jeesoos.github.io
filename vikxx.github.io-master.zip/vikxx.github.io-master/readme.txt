License

Licensed under the Creative Commons Attribution 3.0 license. You can use this template for free in both personal as well as commercial projects. 
